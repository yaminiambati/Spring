package org.cap.controller;

import javax.validation.Valid;

import org.cap.model.Pilot;
import org.cap.service.PilotService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyController {

	@Autowired
	private PilotService pilotService;

	@RequestMapping("/hello")
	public ModelAndView greetUser() {
		return new ModelAndView
				("helloPage", "greetings", "Hello! Good Morning!");
	}
	
	
	@PostMapping("/validatelogin")
	public String validateLogin(ModelMap map, 
			@RequestParam("userName")String userName,
			@RequestParam("userPwd")String userPwd) {
		
		
		if(userName.equals("yamini") && 
				userPwd.equals("123")) {
			map.put("pilot", new Pilot());
			return "pilotForm";
		}
		
		return "redirect:/";
	}
	
	//@RequestMapping(value="/savePilot",method=RequestMethod.POST)
	@PostMapping("/savePilot")
	public String showPilotDetails(
			@Valid @ModelAttribute("pilot") Pilot pilot,
			BindingResult result) {
		if(result.hasErrors()) {
			
			
			return "pilotForm";
		}else {
			pilotService.save(pilot);
		System.out.println(pilot);
		return "showPilot";
		}
	}
}
