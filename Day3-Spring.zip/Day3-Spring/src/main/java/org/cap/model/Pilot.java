package org.cap.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Pilot {
	@Id
	private int pilotId;
	private String firstName;
	
	private String lastName;
	
	private Date dateOfBirth;
	
	private Date dateOfJoin;
	private Boolean isCeritied;
	
	private double salary;
	public int getPilotId() {
		return pilotId;
	}
	public void setPilotId(int pilotId) {
		this.pilotId = pilotId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	
	public Boolean getIsCeritied() {
		return isCeritied;
	}
	public void setIsCeritied(Boolean isCeritied) {
		this.isCeritied = isCeritied;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public Pilot() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public Date getDateOfJoin() {
		return dateOfJoin;
	}
	public void setDateOfJoin(Date dateOfJoin) {
		this.dateOfJoin = dateOfJoin;
	}
	@Override
	public String toString() {
		return "Pilot [pilotId=" + pilotId + ", firstName=" + firstName + ", lastName=" + lastName + ", dateOfBirth="
				+ dateOfBirth + ", dateOfJoin=" + dateOfJoin + ", isCeritied=" + isCeritied + ", salary=" + salary
				+ "]";
	}
	public Pilot(int pilotId, String firstName, String lastName, Date dateOfBirth, Date dateOfJoin, Boolean isCeritied,
			double salary) {
		super();
		this.pilotId = pilotId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfBirth = dateOfBirth;
		this.dateOfJoin = dateOfJoin;
		this.isCeritied = isCeritied;
		this.salary = salary;
	}
	
	
	
	
	
	
}
