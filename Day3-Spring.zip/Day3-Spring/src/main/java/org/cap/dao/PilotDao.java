package org.cap.dao;

import org.cap.model.Pilot;

public interface PilotDao {
		public void save(Pilot pilot);
		

	}