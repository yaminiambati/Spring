package org.cap.dao;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.cap.model.Pilot;
import org.springframework.stereotype.Repository;

import jdk.jfr.Percentage;

@Repository("pilotDao")
@Transactional

public class PilotDaoImpl implements PilotDao {
	
	@PersistenceContext
	private EntityManager em;
	@Transactional
	@Override
	public void save(Pilot pilot) {
		// TODO Auto-generated method stub
		em.persist(pilot);
	}
	@Transactional
	@Override
	public List<Pilot> pilotsgetAll() {
		// TODO Auto-generated method stub
		List<Pilot> pilots = em.createQuery("from Pilot").getResultList();
		return pilots;
	}
	@Transactional
	@Override
	public void delete(Integer pilotId) {
		Pilot pilot= em.find(Pilot.class, pilotId);
		em.remove(pilot);
	}

}
