package org.cap.dao;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.cap.model.Pilot;
import org.springframework.stereotype.Repository;

import jdk.jfr.Percentage;

@Repository("pilotDao")
@Transactional

public class PilotDaoImpl implements PilotDao {
	
	@PersistenceContext
	private EntityManager em;
	@Override
	public void save(Pilot pilot) {
		// TODO Auto-generated method stub
		em.persist(pilot);
	}

}
