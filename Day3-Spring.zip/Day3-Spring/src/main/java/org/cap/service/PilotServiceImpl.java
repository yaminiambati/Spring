package org.cap.service;

import java.util.List;

import org.cap.dao.PilotDao;
import org.cap.model.Pilot;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service("pilotService")
public class PilotServiceImpl implements PilotService {
	@Autowired
	private PilotDao pilotDao;
	@Override
	public void save(Pilot pilot) {
		pilotDao.save(pilot);
	}
	@Override
	public List<Pilot> pilotgetAll() {
		// TODO Auto-generated method stub
		return pilotDao.pilotsgetAll();
	}
	@Override
	public void delete(Integer pilotId) {
		// TODO Auto-generated method stub
		pilotDao.delete(pilotId);
		
	}

}
